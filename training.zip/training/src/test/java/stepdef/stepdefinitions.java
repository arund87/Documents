package stepdef;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import javapackage.xfinitymobilewebapp;

public class stepdefinitions {
	xfinitymobilewebapp webtest=new xfinitymobilewebapp();
	@When("^I goto the Cameras page$")
	public void i_goto_the_Cameras_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Hello1");
		webtest.chrometest();
	}

	@Then("^I find a Camera with Learn more link$")
	public void i_find_a_Camera_with_Learn_more_link() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Hello2");
	}

	@Then("^I validate Learn more link page$")
	public void i_validate_Learn_more_link_page() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Hello3");
	}
	

}
