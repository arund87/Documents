package stepdefinitions;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class learnmorestepdef {
	
	@When("^I goto the Cameras page$")
	public void i_goto_the_Cameras_page() {
	  
	   System.out.println("Test1");
	}

	@Then("^I find a Camera with Learn more link$")
	public void i_find_a_Camera_with_Learn_more_link() {
	   
		System.out.println("Test2");
	}

	@Then("^I validate Learn more link page$")
	public void i_validate_Learn_more_link_page() {
	  
		System.out.println("Test3");
	}

}
